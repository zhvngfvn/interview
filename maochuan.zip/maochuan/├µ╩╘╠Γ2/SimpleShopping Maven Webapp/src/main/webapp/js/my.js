$(document).ready(function() {
		$("#button1").click(function(){
			var flag=false;
			$("#left span").each(function() {
				var o="#"+$(this).attr("id")+"_buy";
				if($(o).val()=="") {
					$(o).val(0);
				}
				if(parseInt($(o).val()) > parseInt($(this).text())) {
					alert("insurficient item:" + $(this).attr("id"));
					$(o).val(0);
					flag=true;
					
				}
			});
			
			//each end
			if(flag==true) {
				return false;
			} else {
				$("#item").submit();
			}
		});
	});