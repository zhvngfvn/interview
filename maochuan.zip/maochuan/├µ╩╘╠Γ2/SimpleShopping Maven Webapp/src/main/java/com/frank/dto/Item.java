package com.frank.dto;

public class Item {
	private String name;
	private Integer quantity;
	private Integer OriginalQuantity;
	public Integer getOriginalQuantity() {
		return OriginalQuantity;
	}
	public void setOriginalQuantity(Integer originalQuantity) {
		OriginalQuantity = originalQuantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
}
