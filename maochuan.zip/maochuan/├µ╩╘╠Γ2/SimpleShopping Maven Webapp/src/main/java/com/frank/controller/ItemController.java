package com.frank.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;  
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;  
  
import org.springframework.stereotype.Controller;  
import org.springframework.ui.Model;  
import org.springframework.web.bind.annotation.RequestMapping;  
  
import com.frank.dto.Item;  
import com.frank.service.impl.ItemServiceImpl;

@Controller  
@RequestMapping("/item")  
public class ItemController {
	
    @RequestMapping("/itemList")  
    public String itemList(HttpServletRequest request,Model model){  
        List<Item> itemList = ItemServiceImpl.getAllItem();
        model.addAttribute("itemList", itemList);
        
        return "itemList";  
    }
    
    @RequestMapping("/resetItem")  
    public String resetItem(HttpServletRequest request,Model model){ 
    	ItemServiceImpl.setItem();
        model.addAttribute("itemList", ItemServiceImpl.getAllItem());
        
        return "itemList";
    }
    
    @RequestMapping("/updateItem")
    public String updateItem(HttpServletRequest request,Model model){
    	Map<String,Integer> parmMap=new HashMap<String,Integer>();  
        Map<String,String[]> map= request.getParameterMap();  
        
        Set<String> key=map.keySet();  
        Iterator<String> iterator = key.iterator();  
        while(iterator.hasNext()){  
            String k=iterator.next();
            
            try {
            	parmMap.put(k, Integer.parseInt(map.get(k)[0]));
            } catch(Exception e) {
            	;
            }
        }  
        
        List<Item> itemList = ItemServiceImpl.getAllItem();
    	for(Item i : itemList) {
    		i.setQuantity(i.getQuantity() - parmMap.get(i.getName()));
    	}
        model.addAttribute("itemList", itemList);
		
		return "itemList";
    }



}
