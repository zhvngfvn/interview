package com.zf.constant;

/** constant calss
 * 
 * @author administrator
 *
 */
public class Constants {
	
	public static final String ITEM_ORDER_NATURE = "NATURAL";
	
	public static final String ITEM_ORDER_SHORT2LONG = "SHORT_TO_LONG";
	
	public static final String ITEM_ORDER_LONG2SHORT = "LONG_TO_SHORT";
	
	public static final String SPLIT_FLAG = ",";
	
	public static final String TRAITS_NUMBER = "^[0-9]+(.[0-9]+)?$";

}
