package com.zf.planner;

/** program limitations
 * 
 * @author administrators
 *
 */
public class PackLimitation {
	
	/** item order of pack*/
	private String orderFlag ;
	
	/** total number of all items in pack*/
	private Integer quantityTotal;
	
	/** total weight of all items in pack*/
	private Double weightTotal;

	/**
	 * @return the orderFlag
	 */
	public String getOrderFlag() {
		return orderFlag;
	}

	/**
	 * @param orderFlag the orderFlag to set
	 */
	public void setOrderFlag(String orderFlag) {
		this.orderFlag = orderFlag;
	}

	/**
	 * @return the quantityTotal
	 */
	public Integer getQuantityTotal() {
		return quantityTotal;
	}

	/**
	 * @param quantityTotal the quantityTotal to set
	 */
	public void setQuantityTotal(Integer quantityTotal) {
		this.quantityTotal = quantityTotal;
	}

	/**
	 * @return the weightTotal
	 */
	public Double getWeightTotal() {
		return weightTotal;
	}

	/**
	 * @param weightTotal the weightTotal to set
	 */
	public void setWeightTotal(Double weightTotal) {
		this.weightTotal = weightTotal;
	}
	
}
