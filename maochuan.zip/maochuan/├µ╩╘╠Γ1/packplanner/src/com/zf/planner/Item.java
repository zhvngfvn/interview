package com.zf.planner;

import com.zf.constant.Constants;


/** item class
 * 
 * @author administrator
 *
 */
public class Item {
	
	/** item id*/
	private String id;
	
	/** item length(mm)*/
	private Integer length;
	
	/** item quantity*/
	private Integer quantity;
	
	/** item weight (kg,the weight of one item)*/
	private Double weight;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the length
	 */
	public Integer getLength() {
		return length;
	}

	/**
	 * @param length the length to set
	 */
	public void setLength(Integer length) {
		this.length = length;
	}

	/**
	 * @return the quantity
	 */
	public Integer getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the weight
	 */
	public Double getWeight() {
		return weight;
	}

	/**
	 * @param weight the weight to set
	 */
	public void setWeight(Double weight) {
		this.weight = weight;
	}
	
	@Override
	public String toString() {
		return id + Constants.SPLIT_FLAG + " " + length
				  + Constants.SPLIT_FLAG + " " + quantity
				  + Constants.SPLIT_FLAG + " " + weight;
	}

}
