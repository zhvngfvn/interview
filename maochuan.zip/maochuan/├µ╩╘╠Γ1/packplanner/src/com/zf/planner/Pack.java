package com.zf.planner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.zf.constant.Constants;
import com.zf.util.RangeComparator;
import com.zf.util.Stack;

/** pack class
 * 
 * @author adminstrator
 *
 */
public class Pack {
	
	/** pack id*/
	private Integer id;
	
	/** item list*/
	private Stack<Item> stack = new Stack<Item>();

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the stack
	 */
	public Stack<Item> getStack() {
		return stack;
	}

	/**
	 * @param stack the stack to set
	 */
	public void setStack(Stack<Item> stack) {
		this.stack = stack;
	}
	
	@Override
	public String toString() {
		StringBuffer pack = new StringBuffer();
		pack.append("Pack number: " + this.id + "\n");
		
		List<Item> list = new ArrayList<Item>();
		Item item = null;
		while((item = this.getStack().pop()) != null){
			list.add(item);
		}
		
		Integer maxLength = 0;
		Double totalWeight = 0.0;
		if(list != null && !list.isEmpty()){
			for(int i=list.size()-1; i>=0; i--){
				
				if(list.get(i).getLength() > maxLength)
					maxLength = list.get(i).getLength();
				
				totalWeight += list.get(i).getQuantity() * list.get(i).getWeight();
				
				pack.append(list.get(i) + "\n");
			}
		}
		
		return pack.toString() + "Pack Length: " + maxLength + ", Pack Weight: " + totalWeight + "\n";
	}
	
}
