package com.zf.planner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.zf.constant.Constants;
import com.zf.util.RangeComparator;

/** PackPlanner class 
 * 
 * @author administrator
 *
 */
public class PackPlanner {
	
	private PackLimitation limitation = new PackLimitation();
	
	public static void main(String[] args) {
		List<Pack> packs = transfer();
		if(packs != null && !packs.isEmpty())
			for(Pack pack : packs){
				System.out.println(pack);
			}
	}
	
	public static List<Pack> transfer() {
		
		PackPlanner planner = new PackPlanner();
		
		//parse standard input
		List<Item> items = planner.readFromInput();
		
		if(items == null || items.isEmpty())
			return null;
		
		
		
		//range items in specified order
		if(!Constants.ITEM_ORDER_NATURE.equals(planner.limitation.getOrderFlag()))
			Collections.sort(items, RangeComparator.short2LongComparator(planner.limitation.getOrderFlag()));
		
		//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		List<Item> itemsNew = new ArrayList<Item>(items);
		
		//push item into pack
		return planner.pushItem2Pack(itemsNew);
	}
	
	/**read items from standard input
	 * 
	 * @return
	 */
	private List<Item> readFromInput(){
		
		try {
			
			if(System.in == null)
				return null;
			
			// convert standard input to buffer reader
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			
			//one line of input
			String line = reader.readLine();
			
			// call setPackLimitation
			String message = setPackLimitation(line);
			
			// item list
			List<Item> items = new ArrayList<Item>();
			
			if(!StringUtils.isBlank(message)){
				System.out.println(message);
				return null;
			}
			
			//parse the buffer reader
			Item item = null;
			while((line = reader.readLine()) != null && !"".equals(line)){
				item = setItem(line);
				if(item != null)
					items.add(item);
			}
			
			return items;
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	/** check the first line information ;
	 *  if it is invalid return failure message ;
	 *  if it is valid set the value of PackLimitation Object and then return null string
	 * @param line
	 * @return
	 */
	private String setPackLimitation(String line){
		
		if(StringUtils.isBlank(line))
			return "The first line is null!";
		
		String[] limitArr = line.split(Constants.SPLIT_FLAG);
		
		if(limitArr == null || limitArr.length != 3)
			return "The quantity of element in the first line is invalid!";
		
		if(!Constants.ITEM_ORDER_NATURE.equals(limitArr[0]) 
				&& !Constants.ITEM_ORDER_SHORT2LONG.equals(limitArr[0]) 
				&& !Constants.ITEM_ORDER_LONG2SHORT.equals(limitArr[0]) )
			return "The order flag must be NATURAL or SHORT_TO_LONG or LONG_TO_SHORT!";
					
		if(!limitArr[1].matches(Constants.TRAITS_NUMBER)) {
			return "The max quantity must be digital !";
		}
		
		if(!limitArr[2].matches(Constants.TRAITS_NUMBER)) {
			System.out.println(!StringUtils.isNumeric(limitArr[2]));
			return "The max weight must be digital !";
		}
		
		limitation.setOrderFlag(limitArr[0]);
		limitation.setQuantityTotal(new Integer(limitArr[1]));
		limitation.setWeightTotal(new Double(limitArr[2]));
		
		return "";
	}
	
	/**check other lines information if it is valid;
	 * if that line is valid then set the value of Item
	 * else drop that line;
	 *
	 * @param line
	 * @return
	 */
	
	private Item setItem(String line){
		
		if(StringUtils.isBlank(line))
			return null;
		
		String[] itemArr = line.split(Constants.SPLIT_FLAG);
		
		if(itemArr == null || itemArr.length != 4)
			return null;
		
		if(!itemArr[1].matches(Constants.TRAITS_NUMBER) 
				|| !itemArr[2].matches(Constants.TRAITS_NUMBER) 
				|| !itemArr[3].matches(Constants.TRAITS_NUMBER))
			return null;
		
		//if piece weight is greater than max weight then this line is valid
		if(this.limitation.getWeightTotal() < new Double(itemArr[3]))
			return null;
		
		Item item = new Item();
		item.setId(itemArr[0]);
		item.setLength(new Integer(itemArr[1]));
		item.setQuantity(new Integer(itemArr[2]));
		item.setWeight(new Double(itemArr[3]));
		
		return item;
	}
	
	/** push item into pack 
	 * 
	 * @param items
	 * @return
	 */
	private List<Pack> pushItem2Pack(List<Item> items){
		
		if(items == null || items.isEmpty())
			return null;
		
		//pack list
		List<Pack> packs = new ArrayList<Pack>();
		
		//accumulated quantity of one pack
		Integer totalQuantity = 0;
		//accumulated weight of one pack
		Double totalWeight = 0.0;
		// pack id
		Integer packNumber = 1;
		//pack object
		Pack pack = new Pack();
		pack.setId(packNumber);
		packs.add(pack);
		
		//traverse item list 
		for(Item item : items){
			
			//check single Item quantity
			List<Item> splitList = new ArrayList<Item>();
			checkQuantity(item,splitList);
			
			for(Item sitem : splitList){
				totalQuantity += sitem.getQuantity();
				totalWeight += sitem.getWeight()*sitem.getQuantity();
				//if accumulated quantity exceeds the specified quantity 
				//or accumulated weight exceeds the specified weight , create a new pack;
				if(this.limitation.getQuantityTotal() < totalQuantity || this.limitation.getWeightTotal() < totalWeight){
					pack = new Pack();
					pack.setId(++packNumber);
					packs.add(pack);
					totalQuantity = sitem.getQuantity();
					totalWeight = sitem.getWeight()*item.getQuantity();
				}
				//put item into pack
				pack.getStack().push(sitem);
			}
			
			
			
		}
		
		return packs;
	}
	
	/** validate single Item if its quantity is greater than the specified quantity
	 *  if it is greanter than specified then split into two Item 
	 * @param item
	 * @param splitList
	 */
	private void checkQuantity(Item item,List<Item> splitList){
		
		Integer itemQ = item.getQuantity();
		
		if(item.getQuantity() > this.limitation.getQuantityTotal()){
			
			item.setQuantity(this.limitation.getQuantityTotal());
			
			checkMaxWeight(item,splitList);
			
			Item itemNew = new Item();
			itemNew.setId(item.getId());
			itemNew.setLength(item.getLength());
			itemNew.setQuantity(itemQ - this.limitation.getQuantityTotal());
			itemNew.setWeight(item.getWeight());
			
			checkQuantity(itemNew,splitList);
			
		}else{
			
			checkMaxWeight(item,splitList);
			
		}
		
	}
	
	/** validate single Item if its weight is greater than the specified weight
	 *  if it is greanter than specified then split into two Item 
	 * @param item
	 * @param splitList
	 */
	private void checkMaxWeight(Item item,List<Item> splitList){
		
		Double weight = item.getQuantity() * item.getWeight();
		Integer itemQ = item.getQuantity();
		
		if(weight > this.limitation.getWeightTotal()){
			
			Integer maxQuantity = new Double(this.limitation.getWeightTotal()/item.getWeight()).intValue();
			
			if(itemQ > maxQuantity){
				
				item.setQuantity(maxQuantity);
				
				splitList.add(item);
				
				Item itemNew = new Item();
				itemNew.setId(item.getId());
				itemNew.setLength(item.getLength());
				itemNew.setQuantity(itemQ - maxQuantity);
				itemNew.setWeight(item.getWeight());
				
				checkMaxWeight(itemNew,splitList);
				
			}else{
				
				splitList.add(item);
				
			}
		}else{
			
			splitList.add(item);
			
		}
	}
	
	
}
