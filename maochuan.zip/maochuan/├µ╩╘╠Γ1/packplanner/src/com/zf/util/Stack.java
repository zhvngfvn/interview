package com.zf.util;

import java.util.LinkedList;

/**The Stack class represents a last-in-first-out (LIFO) stack of objects.
 * 
 * @author administrator
 *
 * @param <T>
 */
public class Stack<T> {
	
	private LinkedList<T> linkedList = new LinkedList<T>();
	
	public void push(T v) { 
		linkedList.addFirst(v); 
	}
	
	public T peek() { 
		return linkedList.getFirst(); 
	}
	
	public T pop() { 
		if(!empty())
			return linkedList.removeFirst();
		return null;
	}
	
	public boolean empty() { 
		return linkedList.isEmpty(); 
	}
	
	public String toString() { 
		return linkedList.toString(); 
	}
	
}
