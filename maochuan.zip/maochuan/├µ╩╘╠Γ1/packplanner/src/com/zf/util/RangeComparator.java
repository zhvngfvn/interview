package com.zf.util;

import java.util.Comparator;

import com.zf.constant.Constants;
import com.zf.planner.Item;

/** range Comparator class
 * 
 * @author administrator
 *
 */
public class RangeComparator {
	
	/** produce different comparator by the value of orderFlag
	 * 
	 * @param orderFlag
	 * @return
	 */
	public static  Comparator<Item> short2LongComparator(String orderFlag){
		
		if(Constants.ITEM_ORDER_SHORT2LONG.equals(orderFlag))
			return new Comparator<Item>(){
				@Override
				public int compare(Item o1, Item o2) {
					return o1.getLength().intValue() - o2.getLength().intValue();
				}
			};
		
		if(Constants.ITEM_ORDER_LONG2SHORT.equals(orderFlag))
			return new Comparator<Item>(){
				@Override
				public int compare(Item o1, Item o2) {
					return o2.getLength().intValue() - o1.getLength().intValue();
				}
			};
			
		return null;
	}

}
